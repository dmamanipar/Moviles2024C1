package pe.edu.upeu.asistencia_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
