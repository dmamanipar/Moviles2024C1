class TokenUtil{
  TokenUtil._();
  static bool localx=false;
  static String TOKEN="";
}