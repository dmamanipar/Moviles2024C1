
class UrlApi{
  UrlApi._();
  static const String urlApix="http://192.168.1.139:8080";
}